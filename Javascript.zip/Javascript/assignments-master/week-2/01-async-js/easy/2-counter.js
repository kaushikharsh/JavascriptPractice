let counter = 0;
function fn()
{
    console.log(counter);
    counter = counter + 1;
    setTimeout(fn,1000);
}
fn();
const fs = require('fs');
function ourOwnWriteFile()
{   
    fs.writeFile("a.txt","Hi this is the  latest message written!!!",function(){
        fs.readFile("a.txt","utf-8",function(err, data)
        {
            console.log(data);
        })
    })
}

ourOwnWriteFile();
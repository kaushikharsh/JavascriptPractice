function counter()
{
    let count = 0;
    setInterval(function(){
        console.log(new Date().getTime() + " counter : " + count);
        count = count + 1;
    },1000);
}
counter();
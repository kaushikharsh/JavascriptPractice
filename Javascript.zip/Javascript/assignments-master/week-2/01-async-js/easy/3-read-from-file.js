const fs = require('fs');

function ourOwnReadFile()
{
    fs.readFile("a.txt","utf-8",function(err,data){
        console.log(data);
    })   
    for(let i=0;i<1000000;i++) // these are some heavy operation after file read!!! its calling the code written after the file method because of callbacks
    {
    } 
    console.log("Hello Before the file executed even defined after the file read code because of sync its happining!!");
}

ourOwnReadFile();
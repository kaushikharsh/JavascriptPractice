const fs = require('fs');

fs.readFile("a.txt","utf-8",function(err, data)
{
    let arr = data.split(' ');
    let ans = "";
    //for loop approach
    // for(let i=0;i<arr.length;i++)
    // {
    //     if(!arr[i].includes(" "))
    //     {
    //         ans = ans.trim() + " " + arr[i];
    //     }
    // }
    //map approach
    arr.map(function(x){
        if(!x.includes(" "))
        {
            ans = ans.trim() + " " + x;
        }
    })
    fs.writeFile("a.txt",ans,function(err, data)
    {
        fs.readFile("a.txt","utf-8",function(err, data){
            console.log(data);
        })
    })
})
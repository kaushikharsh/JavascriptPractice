setInterval(function()
{
    let x = new Date();
    console.log(x.getHours() + ":" + x.getMinutes() + ":" + x.getSeconds());
},1000)